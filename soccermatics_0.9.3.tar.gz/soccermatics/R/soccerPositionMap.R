#' @include soccerPitch.R
#' @import ggplot2
#' @import dplyr
#' @importFrom ggrepel geom_text_repel geom_label_repel
NULL
#' Plot average player position
#' @description Draws the average x,y-positions of each player from one or both teams on a soccer pitch.
#' 
#' @param df dataframe containing x,y-coordinates of player position
#' @param lengthPitch,widthPitch numeric, length and width of pitch in metres
#' @param fill1,fill2 character, fill colour of position points (team 1, team 2 (if present))
#' @param col1,col2 character, border colour of position points (team 1, team 2 (if present))
#' @param homeTeam if \code{df} contains two teams, the name of the home team to be displayed on the left hand side of the pitch. If \code{NULL}, infers home team as the team of the first event in \code{df}.
#' @param nodeSize numeric, size of position points
#' @param label boolean, draw labels
#' @param labelSize numeric, size of labels
#' @param labelCol colour of labels
#' @param arrow optional, adds arrow showing team attack direction as right (\code{'r'}) or left (\code{'l'})
#' @param theme draws a \code{light}, \code{dark}, \code{grey}, or \code{grass} coloured pitch
#' @param title,subtitle optional, adds title and subtitle to plot
#' @param x,y = name of variables containing x,y-coordinates
#' @param id character, the name of the column containing player identity. Defaults to \code{'id'}
#' @param team character, the name of the column containing team identity. Optional, defaults to \code{'NULL'}
#' @examples
#' # average player position; one team w/ labels as player numbers
#' data(tromso)
#' soccerPositionMap(tromso, grass = TRUE)
#' 
#' # average pass position for one team
#' data(statsbomb)
#' statsbomb %>%
#'   filter(type.name == "Pass" & team.name == "France" & minute < 43) %>%
#'   soccerPositionMap(id = "name", x = "location.x", y = "location.y",
#'                     fill1 = "blue",
#'                     arrow = "r",
#'                     title = "France (vs Argentina, 30th June 2018)",
#'                     subtitle = "Average pass position (1' - 42')")
#'                  
#' # average pass position; two teams w/ original names, non-overlapping player names (requires flipping one team in vertical plane for StatsBomb data)
#' statsbomb %>%
#'   filter(type.name == "Pass" & minute < 43) %>%
#'   soccerPositionMap(team = "team.name", id = "player.name", x = "location.x", y = "location.y",
#'                    fill1 = "lightblue", fill2 = "blue", labelCol = "black",
#'                    repel = T, teamToFlip = 2,
#'                    title = "France vs Argentina, 30th June 2018",
#'                    subtitle = "Average pass position (1' - 42')")
#' 
#' @export
soccerPositionMap <- function(df, lengthPitch = 105, widthPitch = 68, fill1 = "red", col1 = NULL, fill2 = "blue", col2 = NULL, homeTeam = NULL, label = TRUE, labelBox = TRUE, shortNames = TRUE, nodeSize = 5, labelSize = 4, labelCol = "black", arrow = c("none", "r", "l"), title = NULL, subtitle = NULL, theme = c("light", "dark", "grey", "grass"), x = "x", y = "y", id = "id", name = "name", team = "team") {
  
  # define colours by theme
  if(theme[1] == "grass") {
    colText <- "white"
  } else if(theme[1] == "light") {
    colText <- "black"
  } else if(theme[1] %in% c("grey", "gray")) {
    colText <- "black"
  } else {
    colText <- "white"
  }
  if(is.null(col1)) col1 <- fill1
  if(is.null(col2)) col2 <- fill2
  
  # set variable names
  df$x <- df[,x]
  df$y <- df[,y]
  df$id <- df[,id]
  df$team <- df[,team]
  df$name <- df[,name]
  
  # shorten player name
  if(shortNames) {
    df$name <- soccerShortenName(df$name)
  }
  
  # if two teams in df
  if(length(unique(df$team)) > 1) {
    
    # home team taken as first team in df if unspecified
    if(is.null(homeTeam)) homeTeam <- df[,team][1]
    
    # flip x,y-coordinates of home team
    df <- df %>% 
      soccerFlipDirection(teamToFlip = homeTeam, periodToFlip = 1:2, x = "x", y = "y", team = "team")
  
    # get average positions
    pos <- df %>%
      group_by(team, id, name) %>%
      dplyr::summarise(x.mean = mean(x), y.mean = mean(y)) %>% 
      # ungroup() %>% 
      # mutate(team = as.factor(team), id = as.factor(id)) %>% 
      as.data.frame()
    
    # plot
    p <- soccerPitch(theme = theme[1], title = title, subtitle = subtitle) +
      geom_point(data = pos, aes(x.mean, y.mean, group = team, fill = team, colour = team), shape = 21, size = 6, stroke = 1.3) +
      scale_colour_manual(values = c(col1, col2)) +
      scale_fill_manual(values = c(fill1, fill2)) +
      guides(colour = FALSE, fill = FALSE)
    
  # if one team...  
  } else {
    # get average positions
    pos <- df %>%
      group_by(id, name) %>%
      dplyr::summarise(x.mean = mean(x), y.mean = mean(y)) %>% 
      # ungroup() %>% 
      # mutate(id = as.factor(id)) %>% 
      as.data.frame()
    
    # plot
    p <- soccerPitch(arrow = arrow, theme = theme[1], title = title, subtitle = subtitle) +
      geom_point(data = pos, aes(x.mean, y.mean), col = col1, fill = fill1, shape = 21, size = nodeSize, stroke = 1.3)
  }
  
  # add non-overlapping labels
  if(label) {
    if(labelBox) {
      p <- p +
        geom_label_repel(data = pos, aes(x.mean, y.mean, label = name), segment.colour = colText, segment.size = 0.3, max.iter = 1000, size = labelSize, fontface = "bold")
    } else {
      p <- p +
        geom_text_repel(data = pos, aes(x.mean, y.mean, label = name), segment.colour = colText, segment.size = 0.3, max.iter = 1000, col = colText, size = labelSize, fontface = "bold")
    }
  }
  
  return(p)
}
